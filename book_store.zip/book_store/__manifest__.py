{
    'name': 'Bookstore',
    'version': '1.0',
    'summary': 'Manage Books in Bookstore',
    'depends': ['base','mail'],
    'data': [
        'security/ir.model.access.csv',
        'views/book_details_views.xml',
        'views/author_wizard_views.xml',
        'data/auto_archive_cron.xml',
        'views/genre_details_views.xml',
        'views/genre_details_views.xml',
        'views/book_summary_views.xml',
    ],
    'installable': True,
    'application': True,
}
