from odoo import models, fields, api

class AuthorWizard(models.TransientModel):
    _name = 'author.wizard'
    _description = 'Author Creation Wizard'

    name = fields.Char(string="Author Name", required=True)
    email = fields.Char(string="Email")  # ✅ Add this field

    def create_author(self):
        partner = self.env['res.partner'].create({
            'name': self.name,
            'email': self.email,
            'author': True
        })
        return {
            'type': 'ir.actions.act_window',
            'res_model': 'res.partner',
            'res_id': partner.id,
            'view_mode': 'form',
            'target': 'current',
        }
