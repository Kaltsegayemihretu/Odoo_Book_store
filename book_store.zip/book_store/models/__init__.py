from . import book_details
from . import res_partner
from . import genre_details
