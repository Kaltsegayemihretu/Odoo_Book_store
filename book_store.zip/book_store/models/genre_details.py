from odoo import models, fields

class GenreDetails(models.Model):
    _name = 'genre.details'
    _description = 'Genre Details'

    name = fields.Char(string='Genre Name', required=True, unique=True)
