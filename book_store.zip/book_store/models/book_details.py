from odoo import models, fields, api
from odoo.exceptions import ValidationError
from datetime import date


class BookDetails(models.Model):
    _name = 'book.details'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = 'Book Details'

    @api.model
    def create(self, vals):
        record = super().create(vals)
        record._check_stock_activity()
        return record

    def write(self, vals):
        res = super().write(vals)
        self._check_stock_activity()
        self._check_archive_notification()
        return res

    def _check_stock_activity(self):
        for book in self:
            if book.stock_qty < 5:
                book.activity_schedule(
                    'mail.mail_activity_data_todo',
                    summary='Low Stock Alert',
                    note='This book has low stock. Consider reordering.',
                    user_id=self.env.user.id,
                    date_deadline=fields.Date.today() + timedelta(days=3)
                )

    def _check_archive_notification(self):
        for book in self:
            if book.is_archived:
                manager = self.env.ref('base.user_admin', raise_if_not_found=False)
                if manager:
                    book.activity_schedule(
                        'mail.mail_activity_data_warning',
                        summary='Book Archived',
                        note='The book "{}" has been archived.'.format(book.name),
                        user_id=manager.id,
                        date_deadline=fields.Date.today()
                    )

    cover_image = fields.Image(string="Cover Image")

    name = fields.Char(string='Title', required=True)
    author_id = fields.Many2one(
        'res.partner', string='Author', domain="[('author', '=', True)]", required=True, tracking=True
    )
    genre_ids = fields.Many2many('genre.details', string='Genres', tracking=True)
    publisher = fields.Char(string='Publisher')
    published_date = fields.Date(string='Published Date', tracking=True)
    book_age = fields.Integer(string='Book Age', compute='_compute_book_age')
    isbn = fields.Char(string='ISBN', unique=True)
    is_archived = fields.Boolean(string='Archived', default=False)
    stock_qty = fields.Float(string='Stock Quantity', tracking=True)
    price = fields.Monetary(string='Price', tracking=True)
    currency_id = fields.Many2one(
        'res.currency', string='Currency', required=True,
        default=lambda self: self.env.company.currency_id
    )

    @api.depends('published_date')
    def _compute_book_age(self):
        for record in self:
            if record.published_date:
                record.book_age = fields.Date.today().year - record.published_date.year
            else:
                record.book_age = 0

    def open_author_wizard(self):
        return {
            'type': 'ir.actions.act_window',
            'name': 'Add New Author',
            'res_model': 'author.wizard',
            'view_mode': 'form',
            'target': 'new',
            'context': {
                'default_name': '',  # Optional: prefill name or email if needed
            },
        }
    
    @api.model
    def _auto_archive_old_books(self):
        cutoff_years = 10
        today = fields.Date.today()
        cutoff_date = date(today.year - cutoff_years, today.month, today.day)

        old_books = self.search([
            ('published_date', '!=', False),
            ('published_date', '<', cutoff_date),
            ('is_archived', '=', False),
        ])
        old_books.write({'is_archived': True})

    @api.constrains('published_date')
    def _check_published_date(self):
        for record in self:
            if record.published_date and record.published_date > date.today():
                raise ValidationError("Published date cannot be in the future.")
            
            
    @api.constrains('stock_qty', 'price')
    def _check_positive_values(self):
        for record in self:
            if record.stock_qty < 0:
                raise ValidationError("Stock quantity cannot be negative.")
            if record.price < 0:
                raise ValidationError("Price cannot be negative.")
            
    @api.constrains('name', 'publisher')
    def _check_required_fields(self):
        for record in self:
            if not record.name.strip():
                raise ValidationError("Book title cannot be empty.")
            if not record.publisher.strip():
                raise ValidationError("Publisher cannot be empty.")

